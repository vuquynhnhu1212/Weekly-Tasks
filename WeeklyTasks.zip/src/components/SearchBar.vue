<!-- src/components/SearchBar.vue -->
<template>
    <div class="search-bar">
      <input 
        type="text" 
        v-model="searchQuery" 
        @input="onSearch" 
        placeholder="Search..." 
      />
      <button @click="clearSearch">Clear</button>
    </div>
  </template>
  
  <script>
  export default {
    name: 'SearchBar',
    data() {
      return {
        searchQuery: '',
      };
    },
    methods: {
      onSearch() {
        this.$emit('search', this.searchQuery);
      },
      clearSearch() {
        this.searchQuery = '';
        this.onSearch(); // Emit the cleared query
      },
    },
  };
  </script>
  
  <style scoped>
  .search-bar {
    display: flex;
    align-items: center;
  }
  
  .search-bar input {
    flex-grow: 1;
    padding: 8px;
    font-size: 1em;
  }
  
  .search-bar button {
    margin-left: 10px;
    padding: 8px 12px;
    cursor: pointer;
  }
  </style>
  