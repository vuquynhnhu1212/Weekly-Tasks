<template>
  <div v-if="duplicateWords.length" class="duplicate-word-warning">
    <h2>Duplicated Words</h2>
    <ul>
      <li v-for="(duplicate, index) in duplicateWords" :key="index">
        <p><strong>{{ duplicate.language }}:</strong> {{ duplicate.word }}</p>
      </li>
    </ul>
  </div>
</template>

<script>
import { api } from '../helpers/helpers';

export default {
  name: 'checkDuplicate',
  props: {
    word: {
      type: Object,
      required: false,
      default: () => ({
        english: '',
        german: '',
        french: ''
      })
    }
  },
  data() {
    return {
      duplicateWords: [], // Initialize the duplicateWords data property
      errorsPresent: false
    };
  },
  methods: {
    async checkDuplicate(word) {
      try {
        this.duplicateWords = [];  // Clear previous duplicates

        // Check for duplicates in each language
        const englishDuplicate = await api.checkDuplicate({ english: this.word.english });
        const germanDuplicate = await api.checkDuplicate({ german: this.word.german });
        const frenchDuplicate = await api.checkDuplicate({ french: this.word.french });

        if (englishDuplicate && englishDuplicate._id !== word._id) {
          this.duplicateWords.push({ language: 'English', word: englishDuplicate.english });
        }
        if (germanDuplicate && germanDuplicate._id !== word._id) {
          this.duplicateWords.push({ language: 'German', word: germanDuplicate.german });
        }
        if (frenchDuplicate && frenchDuplicate._id !== word._id) {
          this.duplicateWords.push({ language: 'French', word: frenchDuplicate.french });
        }

        // Handle result when no duplicates are found
        if (this.duplicateWords.length === 0) {
          this.flash('No duplicates found, proceeding with update.', 'success');
          await api.updateWord(word);
          this.flash('Word updated successfully!', 'success');
          this.$router.push(`/words/${word._id}`);
        }
      } catch (error) {
        this.flash('An error occurred while checking for duplicates.', 'error');
      }
    }
  }
};
</script>

<style scoped>
.duplicate-word-warning {
  background-color: #ffdddd;
  border: 1px solid #f5c6cb;
  padding: 15px;
  margin-top: 20px;
  border-radius: 5px;
}
</style>
