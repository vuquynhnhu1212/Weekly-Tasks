<template>
    <div class="pagination">
      <button
        @click="goToPage(currentPage - 1)"
        :disabled="currentPage === 1"
      >
        Previous
      </button>
      
      <button
        v-for="page in pagesToShow"
        :key="page"
        @click="goToPage(page)"
        :class="{ active: page === currentPage }"
      >
        {{ page }}
      </button>
      
      <button
        @click="goToPage(currentPage + 1)"
        :disabled="currentPage === totalPages"
      >
        Next
      </button>
    </div>
  </template>
  
  <script setup>
  import { ref, computed } from 'vue';
  
  const props = defineProps({
    totalItems: {
      type: Number,
      required: true,
    },
    itemsPerPage: {
      type: Number,
      required: true,
    },
    modelValue: {
      type: Number,
      default: 1,
    },
  });
  
  const emit = defineEmits(['update:modelValue']);
  
  const currentPage = ref(props.modelValue);
  
  const totalPages = computed(() => {
    return Math.ceil(props.totalItems / props.itemsPerPage);
  });
  
  const pagesToShow = computed(() => {
    const pages = [];
    for (let page = 1; page <= totalPages.value; page++) {
      // Check if the previous page exceeds the itemsPerPage limit
      if (page === 1 || props.totalItems >= (page - 1) * props.itemsPerPage) {
        pages.push(page);
      }
    }
    return pages;
  });
  
  const goToPage = (page) => {
    if (page >= 1 && page <= totalPages.value) {
      currentPage.value = page;
      emit('update:modelValue', page);
    }
  };
  </script>
  
  <style scoped>
  .pagination {
    display: flex;
    gap: 0.5rem;
  }
  
  button.active {
    font-weight: bold;
  }
  
  button:disabled {
    opacity: 0.5;
    pointer-events: none;
  }
  </style>
  