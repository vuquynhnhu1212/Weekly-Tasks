<template>
    <div>
        <h1>New Word</h1>
        <word-form @createOrUpdate="createOrUpdate"></word-form>

        <!-- Section to display any duplicate words detected -->
        <div v-if="duplicateWords.length" class="duplicate-word-warning">
            <h2>Duplicated Words</h2>
            <ul>
                <li v-for="(word, index) in duplicateWords" :key="index">
                    <p><strong>{{ word.language }} Duplicate:</strong> {{ word.value }}</p>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import WordForm from '../components/WordForm.vue';
import { api } from '../helpers/helpers';

export default {
    name: 'new-word',
    components: {
        'word-form': WordForm
    },
    data() {
        return {
            duplicateWords: []  // Store the detected duplicate words here
        };
    },
    methods: {
        async createOrUpdate(word) {
            try {
                this.duplicateWords = [];  // Clear previous duplicates

                // Check for duplicates in each language
                const [englishDuplicate, germanDuplicate, frenchDuplicate] = await Promise.all([
                    api.checkDuplicate({ english: word.english }),
                    api.checkDuplicate({ german: word.german }),
                    api.checkDuplicate({ french: word.french })
                ]);

                // Collect duplicates
                if (englishDuplicate && englishDuplicate._id) {
                    this.duplicateWords.push({ language: 'English', value: englishDuplicate.english });
                }
                if (germanDuplicate && germanDuplicate._id) {
                    this.duplicateWords.push({ language: 'German', value: germanDuplicate.german });
                }
                if (frenchDuplicate && frenchDuplicate._id) {
                    this.duplicateWords.push({ language: 'French', value: frenchDuplicate.french });
                }

                if (this.duplicateWords.length) {
                    this.flash('Duplicate words detected!', 'error');
                } else {
                    // Proceed with creating the word if no duplicates are found
                    const res = await api.createWord(word);
                    this.flash('Word created successfully!', 'success');
                    this.$router.push(`/words/${res._id}`);
                }
            } catch (error) {
                this.flash('An error occurred while checking for duplicates or creating the word.', 'error');
            }
        }
    }
};
</script>

<style scoped>
.duplicate-word-warning {
    background-color: #ffdddd;
    border: 1px solid #f5c6cb;
    padding: 15px;
    margin-top: 20px;
    border-radius: 5px;
}
</style>
