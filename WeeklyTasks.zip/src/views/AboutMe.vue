
<template>
    <div class="about-me">
      <h1>Vu Quynh Nhu page</h1>
      <p>This page belongs to Vu Quynh Nhu and has been added to the system working on my own to demonstrate my ability to add a new item to the menu bar with a new icon of my choice attaching a template from a new view.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'AboutMe'
  }
  </script>
  
  <style scoped>
  .about-me {
    padding: 20px;
    text-align: left;
  }
  h1 {
    font-size: 2em;
    margin-bottom: 20px;
  }
  p {
    font-size: 1.2em;
  }
  </style>
  