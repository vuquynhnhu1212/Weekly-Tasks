<template>
  <div>
    <h1>Words</h1>
    
    <!-- SearchBar component -->
    <SearchBar @search="handleSearch" />
    
    <table id="words" class="ui celled compact table">
      <thead>
        <tr>
          <th>English</th>
          <th>German</th>
          <th>French</th>
          <th colspan="3"></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(word, i) in paginatedWords" :key="i">
          <td>{{ word.english }}</td>
          <td>{{ word.german }}</td>
          <td>{{ word.french }}</td>
          <td width="75" class="center aligned">
            <router-link :to="{ name: 'show', params: { id: word._id } }">Show</router-link>
          </td>
          <td width="75" class="center aligned">
            <router-link :to="{ name: 'edit', params: { id: word._id } }">Edit</router-link>
          </td>
          <td width="75" class="center aligned" @click.prevent="onDestroy(word._id)">
            <a :href="`/words/${word._id}`">Destroy</a>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Pagination component -->
    <Pagination
      :totalItems="filteredWords.length"
      :itemsPerPage="itemsPerPage"
      v-model="currentPage"
      @update:modelValue="goToPage"
    />
  </div>
</template>

<script>
import { RouterLink } from 'vue-router';
import { api } from '../helpers/helpers';
import Pagination from '../components/Pagination.vue';
import SearchBar from '../components/SearchBar.vue';

export default {
  name: 'words',
  components: {
    Pagination,
    SearchBar,
  },
  data() {
    return {
      words: [],
      currentPage: 1,
      itemsPerPage: 5, // Adjust the number of items per page here
      searchQuery: '', // Added search query state
    };
  },
  computed: {
    filteredWords() {
      if (!this.searchQuery) {
        return this.words;
      }
      return this.words.filter(word =>
        word.english.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        word.german.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        word.french.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    },
    paginatedWords() {
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;
      return this.filteredWords.slice(start, end);
    },
  },
  methods: {
    handleSearch(query) {
      this.searchQuery = query;
      this.currentPage = 1; // Reset to the first page on search
    },
    goToPage(page) {
      if (page >= 1 && page <= Math.ceil(this.filteredWords.length / this.itemsPerPage)) {
        this.currentPage = page;
      }
    },
    async onDestroy(id) {
      const sure = window.confirm('Are you sure?');
      if (!sure) return;
      await api.deleteWord(id);
      this.flash('Word deleted successfully!', 'success');
      this.words = this.words.filter(word => word._id !== id);
    },
  },
  async mounted() {
    this.words = await api.getWords();
  },
};
</script>
