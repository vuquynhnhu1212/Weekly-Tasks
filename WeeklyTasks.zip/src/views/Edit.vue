<template>
  <div>
    <h1>Edit Word</h1>
    <word-form @createOrUpdate="createOrUpdate" :word="word"></word-form>

    <!-- Section to display any duplicate words detected -->
    <div v-if="duplicateWords.length" class="duplicate-word-warning">
      <h2>Duplicated Words</h2>
      <ul>
        <li v-for="(duplicate, index) in duplicateWords" :key="index">
          <p><strong>{{ duplicate.language }} Duplicate:</strong> {{ duplicate.value }}</p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import WordForm from '../components/WordForm.vue';
import { api } from '../helpers/helpers';

export default {
  name: 'edit',
  components: {
    'word-form': WordForm
  },
  data() {
    return {
      word: {},
      duplicateWords: []  // Array to store detected duplicates
    };
  },
  async mounted() {
    this.word = await api.getWord(this.$route.params.id);
  },
  methods: {
    async createOrUpdate(word) {
      try {
        this.duplicateWords = [];  // Clear previous duplicates

        // Check for duplicates in each language
        const [englishDuplicate, germanDuplicate, frenchDuplicate] = await Promise.all([
          api.checkDuplicate({ english: word.english }),
          api.checkDuplicate({ german: word.german }),
          api.checkDuplicate({ french: word.french })
        ]);

        // Collect duplicates
        if (englishDuplicate && englishDuplicate._id && englishDuplicate._id !== word._id) {
          this.duplicateWords.push({ language: 'English', value: englishDuplicate.english });
        }
        if (germanDuplicate && germanDuplicate._id && germanDuplicate._id !== word._id) {
          this.duplicateWords.push({ language: 'German', value: germanDuplicate.german });
        }
        if (frenchDuplicate && frenchDuplicate._id && frenchDuplicate._id !== word._id) {
          this.duplicateWords.push({ language: 'French', value: frenchDuplicate.french });
        }

        // If duplicates are found, display message
        if (this.duplicateWords.length) {
          this.flash('Duplicate words detected!', 'error');
        } else {
          // Proceed with updating the word if no duplicates are found
          await api.updateWord(word);
          this.flash('Word updated successfully!', 'success');
          this.$router.push(`/words/${word._id}`);
        }
      } catch (error) {
        this.flash('An error occurred while checking for duplicates or updating the word.', 'error');
      }
    }
  }
};
</script>

<style scoped>
.duplicate-word-warning {
  background-color: #ffdddd;
  border: 1px solid #f5c6cb;
  padding: 15px;
  margin-top: 20px;
  border-radius: 5px;
}
</style>
