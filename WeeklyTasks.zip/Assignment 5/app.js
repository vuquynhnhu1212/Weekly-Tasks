//Requiring module
const express = require('express');

//Creating express object
const app = express();

// Handling GET request for home page
app.get('/', (req, res) => {
    res.send('This is home page.');
});

// Handling GET request for student page
app.get('/student', (req, res) => {
    res.send('This is student page.');
});

// Handling GET request for admin page
app.get('/admin', (req, res) => {
    res.send('This is admin page.');
});

// Handling GET request for data page
app.get('/data', (req, res) => {
    res.json({ message: "Hello World JSON" });
});

// Handling invalid request
app.use((req, res) => {
    res.status(404).send('Invalid Request!');
});

// Port Number
const PORT = process.env.PORT || 8080;

// Server Setup
app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
});
